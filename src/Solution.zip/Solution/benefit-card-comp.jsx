import React from "react";
import './benefit-card-comp.css'



function BCard() {

	return (


		<div className="benCard">
			<div class="card">
			<div class="card-image car-1"></div>
			<h2>Card 1</h2>
			<p>An immersive visual experience is the result of the use of the latest large screen display technologies
			</p>
			<div>
				<a href="https://edcviit.com/">Read More</a>
			</div>


		</div>

		</div>
		


	)


}
export default BCard;
