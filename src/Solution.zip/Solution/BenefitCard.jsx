import React from 'react';
import './BenefitCard.css';
import BCard from './benefit-card-comp'

function Card() {

return(
<body >
		<div class="mainC" style={{ display: "flex", flexWrap: "wrap"}} >
			

             <BCard/>
			 <BCard/>
			 <BCard/>
			 <BCard/>

			

		</div>

</body>
)
}
export default Card;