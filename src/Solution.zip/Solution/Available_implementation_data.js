import image1 from "../assets/carouselImage1.jpeg";
import image2 from "../assets/carouselImage2.jpeg";
import image3 from "../assets/carouselImage3.jpeg";
import image4 from "../assets/carouselImage4.jpeg";
import image5 from "../assets/carouselImage5.jpeg";
import image6 from "../assets/carouselImage6.jpeg";



export const data = [image1, image2, image3, image4, image5, image6];