export const sliderData = [
    {
      image: "https://images.pexels.com/photos/5026349/pexels-photo-5026349.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
      heading: "AUDITORIUM",
      desc: "Conducting live events in auditoriums is often a complex and taxing task – but the latest Networked (AV) Audio Visual technologies can make them more impressive, and simpler to manage.",
    },
    {
      image: "https://images.pexels.com/photos/5511125/pexels-photo-5511125.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
      heading: "MEETING ROOM",
      desc: "This is the description of slide two Lorem ipsum dolor, sit amet consectetur adipisicing elit. Modi quos quas, voluptatum nesciunt illum exercitationem.",
    },
    {
      image: "https://images.pexels.com/photos/5733815/pexels-photo-5733815.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
      heading: "TRAINING ROOM",
      desc: "This is the description of slide three Lorem ipsum dolor, sit amet consectetur adipisicing elit. Modi quos quas, voluptatum nesciunt illum exercitationem.",
    },
  ];