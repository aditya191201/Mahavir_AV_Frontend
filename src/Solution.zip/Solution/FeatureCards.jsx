import React from "react";
import './FeatureCards.css'
import FCard from "./feature-card-comp";

function Feature()
{
  return(
   <div class= "bbody">

    <FCard/> 
    <FCard/> 
    <FCard/> 
    <FCard/>
    
   
  </div>
  )


}
export default Feature;

