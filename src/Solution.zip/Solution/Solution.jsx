import { faHourglass1 } from '@fortawesome/free-solid-svg-icons';
import React from 'react'
import './Solution.css'
import Slider from './Slider';
import Feature from './FeatureCards';
import Card from './BenefitCard';
// import ImplSlider from './Sol-implementation';
import Carousel from './Available_implementation_Carousel';

function Solution() {


   return (

      <>
         <div>
            <Slider />
         </div>


         <section>

            <p className='About-Sol'>
               An immersive visual experience is the result of the use of the latest large screen display technologies — for high-contrast, high resolution images and video.
               Well integrated AV technology improves the quality of internal and external events involving a large number of stakeholders.
            </p>


         </section>
        
        
         <div >
         <h1  style={{ paddingLeft: "50px", marginBottom:"30px", fontSize: "30px", fontFamily: " Arial, Helvetica, sans-serif" }}>
            Features:
         </h1>


         <div>
            <Feature />
         </div>

         <h1  style={{ paddingLeft: "50px", paddingTop:"70px", fontSize: "30px", fontFamily: "Arial, Helvetica, sans-serif" }}>
            Benefits:
         </h1>
         <div>
            <Card />
         </div>
         <div>
         <h1 style={{ paddingLeft: "50px" , marginTop:"15px", marginBottom:"15px" , fontSize: "30px", fontFamily: "Arial, Helvetica, sans-serif"}}>
                    Available Implementation: 
             </h1>
         </div>


         </div>

        
        
{/*         
         <div className='Implementation'>
            <Slider />
         </div> */}
         {/* <div>
         <ImplSlider />
         </div> */}
         <div>
         <Carousel />
         </div>

      </>


   )
}

export default Solution;